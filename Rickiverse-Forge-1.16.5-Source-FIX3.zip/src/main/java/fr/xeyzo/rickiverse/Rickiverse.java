package fr.xeyzo.rickiverse;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(Rickiverse.MOD_ID)
public class Rickiverse {
    public static final String MOD_ID = "rickiverse";

    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class RegistryEvents {
        @SubscribeEvent
        public static void registerItems(final RegistryEvent.Register<Item> event) {
            event.getRegistry().registerAll(
                new GadgetItem("portal_projector", "Unstable Portal Projector"),
                new GadgetItem("cronenberg_serum", "Cronenberg Serum"),
                new GadgetItem("plumbus", "Plumbus"),
                new GadgetItem("meeseeks_cube", "Meeseeks Summoning Cube")
            );
        }
    }

    private static class GadgetItem extends Item {
        private final String kind;

        GadgetItem(String registryName, String displayName) {
            super(new Item.Properties().group(ItemGroup.TOOLS).maxStackSize(1)
                .rarity("portal_projector".equals(registryName) ? Rarity.EPIC : Rarity.UNCOMMON));
            this.kind = registryName;
            setRegistryName(MOD_ID, registryName);
        }

        @Override
        public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
            ItemStack held = player.getHeldItem(hand);
            if (!world.isRemote) {
                switch (kind) {
                    case "portal_projector": {
                        Vector3d look = player.getLookVec();
                        double x = player.getPosX() + look.x * 7.0;
                        double y = player.getPosY();
                        double z = player.getPosZ() + look.z * 7.0;
                        player.setPosition(x, y, z);
                        player.sendStatusMessage(new StringTextComponent("§5[RICKIVERSE] §dRupture interdimensionnelle instable !"), true);
                        break;
                    }
                    case "cronenberg_serum":
                        player.addPotionEffect(new EffectInstance(Effects.NAUSEA, 20 * 12, 0));
                        player.addPotionEffect(new EffectInstance(Effects.SPEED, 20 * 12, 1));
                        player.addPotionEffect(new EffectInstance(Effects.JUMP_BOOST, 20 * 12, 1));
                        player.sendStatusMessage(new StringTextComponent("§2[CRONENBERG] §aVotre ADN vient de prendre une décision discutable."), false);
                        break;
                    case "plumbus":
                        player.addPotionEffect(new EffectInstance(Effects.LUCK, 20 * 30, 0));
                        player.sendStatusMessage(new StringTextComponent("§dLe Plumbus bourdonne. Personne ne sait pourquoi."), false);
                        break;
                    case "meeseeks_cube": {
                        ZombieEntity meeseeks = EntityType.ZOMBIE.create(world);
                        if (meeseeks != null) {
                            meeseeks.setPosition(player.getPosX() + 1.5, player.getPosY(), player.getPosZ() + 1.5);
                            meeseeks.setCustomName(new StringTextComponent("§bMr. Meeseeks"));
                            meeseeks.setCustomNameVisible(true);
                            world.addEntity(meeseeks);
                        }
                        player.sendStatusMessage(new StringTextComponent("§bI'm Mr. Meeseeks! Look at me! (version zombie expérimentale)"), false);
                        break;
                    }
                }
            }
            return ActionResult.resultSuccess(held);
        }
    }
}
