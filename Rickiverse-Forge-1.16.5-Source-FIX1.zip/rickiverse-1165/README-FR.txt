RICKIVERSE — prototype Minecraft Java 1.16.5 + Forge
====================================================

Ce projet est une base de prototype, pas encore un mod validé en jeu.
Il ajoute quatre objets de test : projecteur de faille, sérum Cronenberg,
Plumbus et cube Meeseeks. Le cube invoque temporairement un zombie renommé.
Le projecteur est une téléportation expérimentale courte, pas encore un vrai
système de portails ou de dimensions.

COMPILATION DISTANTE VIA GITHUB ACTIONS (depuis Android)
-------------------------------------------------------
1. Crée un compte GitHub si tu n'en as pas, puis crée un dépôt PUBLIC vide
   nommé Rickiverse (ne coche pas l'option README).
2. Pour que GitHub puisse lancer le build, le dossier du projet doit être
   envoyé dans le dépôt en conservant l'arborescence, notamment le dossier
   .github/workflows/build.yml. Le ZIP seul ne suffit pas : GitHub ne le
   décompresse pas automatiquement.
3. Une fois les fichiers envoyés, ouvre l'onglet Actions du dépôt.
4. Choisis “Build RICKIVERSE”, puis “Run workflow” si nécessaire.
5. Attends la fin du workflow. S'il est vert, ouvre l'exécution puis la section
   Artifacts et télécharge “Rickiverse-Minecraft-1.16.5-Forge”.
6. Décompresse l'archive téléchargée : elle contient le fichier .jar à placer
   dans le dossier mods de l'instance Forge 1.16.5.

Si l'étape de compilation échoue, ne mets pas le JAR dans Minecraft. Ouvre
l'exécution GitHub Actions, copie les dernières lignes de l'erreur et demande
une correction. Un build vert ne remplace pas un test en jeu.

Détails techniques : Forge 1.16.5-36.2.39, mappings officiels, Java 8.
