package fr.xeyzo.rickiverse;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.ObjectHolder;

@Mod(Rickiverse.MOD_ID)
public class Rickiverse {
    public static final String MOD_ID = "rickiverse";

    public Rickiverse() {
        FMLJavaModLoadingContext.get().getModEventBus().register(this);
    }

    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class RegistryEvents {
        @SubscribeEvent
        public static void registerItems(final RegistryEvent.Register<Item> event) {
            event.getRegistry().registerAll(
                new GadgetItem("portal_projector", "Unstable Portal Projector"),
                new GadgetItem("cronenberg_serum", "Cronenberg Serum"),
                new GadgetItem("plumbus", "Plumbus"),
                new GadgetItem("meeseeks_cube", "Meeseeks Summoning Cube")
            );
        }
    }

    private static class GadgetItem extends Item {
        private final String kind;

        GadgetItem(String registryName, String displayName) {
            super(new Item.Properties().tab(ItemGroup.TAB_TOOLS).stacksTo(1)
                    .rarity("portal_projector".equals(registryName) ? Rarity.EPIC : Rarity.UNCOMMON));
            this.kind = registryName;
            setRegistryName(MOD_ID, registryName);
        }

        @Override
        public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            if (!world.isClientSide) {
                switch (kind) {
                    case "portal_projector": {
                        Vector3d look = player.getLookAngle();
                        double x = player.getX() + look.x * 7.0;
                        double y = player.getY();
                        double z = player.getZ() + look.z * 7.0;
                        player.setPos(x, y, z);
                        player.displayClientMessage(new StringTextComponent("§5[RICKIVERSE] §dRupture interdimensionnelle instable !"), true);
                        break;
                    }
                    case "cronenberg_serum":
                        player.addEffect(new EffectInstance(Effects.CONFUSION, 20 * 12, 0));
                        player.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 20 * 12, 1));
                        player.addEffect(new EffectInstance(Effects.JUMP, 20 * 12, 1));
                        player.displayClientMessage(new StringTextComponent("§2[CRONENBERG] §aVotre ADN vient de prendre une décision discutable."), false);
                        break;
                    case "plumbus":
                        player.addEffect(new EffectInstance(Effects.LUCK, 20 * 30, 0));
                        player.displayClientMessage(new StringTextComponent("§dLe Plumbus bourdonne. Personne ne sait pourquoi."), false);
                        break;
                    case "meeseeks_cube":
                        ZombieEntity meeseeks = new ZombieEntity(world);
                        meeseeks.setPos(player.getX() + 1.5, player.getY(), player.getZ() + 1.5);
                        meeseeks.setCustomName(new StringTextComponent("§bMr. Meeseeks"));
                        meeseeks.setCustomNameVisible(true);
                        world.addFreshEntity(meeseeks);
                        player.displayClientMessage(new StringTextComponent("§bI'm Mr. Meeseeks! Look at me! (version zombie expérimentale)"), false);
                        break;
                }
            }
            return ActionResult.sidedSuccess(player.getItemInHand(hand), world.isClientSide);
        }
    }
}
